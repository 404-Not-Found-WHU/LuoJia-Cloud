﻿using System;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI;

namespace OnlineSupermarketTuto.Views
{
    public partial class Register : System.Web.UI.Page
    {
        Models.Functions Con;
        protected void Page_Load(object sender, EventArgs e)
        {
            Con = new Models.Functions();
        }

        protected void RegisterBtn_Click(object sender, EventArgs e)
        {
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            string passwordPattern = @"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$";
            string phonePattern = @"^\d{11}$"; 

            if (string.IsNullOrEmpty(NameTb.Value) ||
                string.IsNullOrEmpty(MailTb.Value) ||
                string.IsNullOrEmpty(PasswordTb.Value) ||
                string.IsNullOrEmpty(PhoneTb.Value))
            {
                ErrMsg.Text = "请填写所有必填字段！";
            }
            else if (!Regex.IsMatch(MailTb.Value, emailPattern))
            {
                ErrMsg.Text = "请输入有效的邮箱地址！";
            }
            else if (!Regex.IsMatch(PasswordTb.Value, passwordPattern))
            {
                ErrMsg.Text = "密码必须至少6位，包含字母和数字！";
            }
            else if (!Regex.IsMatch(PhoneTb.Value, phonePattern))
            {
                ErrMsg.Text = "请输入有效的11位电话号码！";
            }
            else
            {
     
                var allCustomers = Con.GetData("Select * from CustomerTb1").AsEnumerable();
                var existCustomer = allCustomers.FirstOrDefault(row =>
                    row.Field<string>("CustEmail") == MailTb.Value);

                if (existCustomer != null)
                {
                    ErrMsg.Text = "该邮箱已被注册！";
                }
                else
                {
                  
                    string query = $"insert into CustomerTb1 (CustName, CustEmail, CustPass, CustPhone) " +
                                   $"values ('{NameTb.Value}', '{MailTb.Value}', '{PasswordTb.Value}', '{PhoneTb.Value}')";
                    Con.SetData(query);
                    ErrMsg.Text = "注册成功，请登录！";
                 
                     Response.Redirect("Login.aspx");
                }
            }
        }
    }
}