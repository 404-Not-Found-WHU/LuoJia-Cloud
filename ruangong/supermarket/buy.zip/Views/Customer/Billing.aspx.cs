﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using QRCoder;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Drawing;
using System.Drawing.Imaging;

namespace OnlineSupermarketTuto.Views.Customer
{
    public partial class Billing : System.Web.UI.Page
    {
        Models.Functions Con;
        int customer = Login.User;
        

        protected void Page_Load(object sender, EventArgs e)
        {
            Con = new Models.Functions();
            if (!IsPostBack)
            {
                ShowProducts();
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[5]
                {
                    new DataColumn("序号"),
                    new DataColumn("商品名称"),
                    new DataColumn("价格"),
                    new DataColumn("数量"),
                    new DataColumn("总计"),
                });
                ViewState["账单"] = dt;
                this.BindGrid();
            }
        }

        protected void BindGrid()
        {
            ShoppingCartList.DataSource = ViewState["账单"];
            ShoppingCartList.DataBind();
        }

        private void ShowProducts()
        {
            string Query = "Select PId, PName, PPrice, PQty from ProductTb1";
            ProductList.DataSource = Con.GetData(Query);
            ProductList.DataBind();
            SetChineseHeaders();
        }

        private void SetChineseHeaders()
        {
                ProductList.HeaderRow.Cells[1].Text = "序号";
                ProductList.HeaderRow.Cells[2].Text = "商品名称";
                ProductList.HeaderRow.Cells[3].Text = "价格";
                ProductList.HeaderRow.Cells[4].Text = "库存";
        }

        int stock = 0;
        protected void ProductList_SelectedIndexChanged(object sender, EventArgs e)
        {
            PnameTb.Value = ProductList.SelectedRow.Cells[2].Text;
            PriceTb.Value = ProductList.SelectedRow.Cells[3].Text;
            stock = Convert.ToInt32(ProductList.SelectedRow.Cells[4].Text);
            
        }

        private void UpdateStock()
        {
            int NewQty;
            NewQty = Convert.ToInt32(ProductList.SelectedRow.Cells[4].Text) - Convert.ToInt32(QtyTb.Value);
            string Query = "Update ProductTb1 set PQty={0} where PId={1}";
            Query = string.Format(Query, NewQty, ProductList.SelectedRow.Cells[1].Text);
            Con.SetData(Query);
            ShowProducts();
        }

        private void InsertBill()
        {
            string Query = "insert into BillTb1 values('{0}',{1},{2})";
            Query = string.Format(Query, DateTime.Today.Date.ToString(), customer, Convert.ToInt32(GrdTotalTb.Text));
            Con.SetData(Query);
        }

        int GrdTotal = 0;
        int Amount;
        protected void AddToBillBtn_Click(object sender, EventArgs e)
        {
            
                int total = Convert.ToInt32(QtyTb.Value) * Convert.ToInt32(PriceTb.Value);
                DataTable dt = (DataTable)ViewState["账单"];
                dt.Rows.Add(ShoppingCartList.Rows.Count + 1,
                    PnameTb.Value.Trim(),
                    PriceTb.Value.Trim(),
                    QtyTb.Value.Trim(),
                    total);

                ViewState["账单"] = dt;

                this.BindGrid();
                UpdateStock();
                GrdTotal = 0;
                for (int i = 0; i < ShoppingCartList.Rows.Count; i++)
                {
                    GrdTotal += Convert.ToInt32(ShoppingCartList.Rows[i].Cells[4].Text);
                }
                Amount = GrdTotal;
                RMBLabel.Text = "¥";
                GrdTotalTb.Text = GrdTotal.ToString();
                PnameTb.Value = "";
                QtyTb.Value = "";
                PriceTb.Value = "";
        }

        protected void PrintBtn_Click(object sender, EventArgs e)
        {
            DataTable dt = ViewState["账单"] as DataTable;
            if (dt == null || dt.Rows.Count == 0)
            {
                return;
            }

            string qrContent = $"总金额：{GrdTotalTb.Text}";
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(qrContent, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);

            using (MemoryStream ms = new MemoryStream())
            {
                Document doc = new Document(PageSize.A4, 40, 40, 40, 40);
                PdfWriter.GetInstance(doc, ms);
                doc.Open();

                string fontPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Fonts), "simsun.ttc,0");
                BaseFont baseFont = BaseFont.CreateFont(fontPath, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                iTextSharp.text.Font font = new iTextSharp.text.Font(baseFont, 12, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);

                PdfPTable table = new PdfPTable(5);
                table.WidthPercentage = 100;
                table.SetWidths(new float[] { 1f, 4f, 2f, 2f, 2f }); 

                string[] headers = { "序号", "商品名称", "价格", "数量", "总计" };
                foreach (string header in headers)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(header, font));
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                    cell.Padding = 5f;
                    table.AddCell(cell);
                }

                foreach (DataRow row in dt.Rows)
                {
                    PdfPCell cell1 = new PdfPCell(new Phrase(row["序号"].ToString(), font));
                    cell1.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell1.Padding = 5f;
                    table.AddCell(cell1);

                    PdfPCell cell2 = new PdfPCell(new Phrase(row["商品名称"].ToString(), font));
                    cell2.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell2.Padding = 5f;
                    table.AddCell(cell2);

                    PdfPCell cell3 = new PdfPCell(new Phrase(row["价格"].ToString(), font));
                    cell3.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell3.Padding = 5f;
                    table.AddCell(cell3);

                    PdfPCell cell4 = new PdfPCell(new Phrase(row["数量"].ToString(), font));
                    cell4.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell4.Padding = 5f;
                    table.AddCell(cell4);

                    PdfPCell cell5 = new PdfPCell(new Phrase(row["总计"].ToString(), font));
                    cell5.HorizontalAlignment = Element.ALIGN_LEFT;
                    cell5.Padding = 5f;
                    table.AddCell(cell5);
                }

                PdfPCell totalCell = new PdfPCell(new Phrase($"总金额：{GrdTotalTb.Text}", font));
                totalCell.Colspan = 5;
                totalCell.HorizontalAlignment = Element.ALIGN_LEFT;
                totalCell.PaddingTop = 10f;
                totalCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                table.AddCell(totalCell);

                doc.Add(table);

                using (MemoryStream qrMs = new MemoryStream())
                {
                    qrCodeImage.Save(qrMs, System.Drawing.Imaging.ImageFormat.Png);
                    iTextSharp.text.Image pdfImage = iTextSharp.text.Image.GetInstance(qrMs.ToArray());
                    pdfImage.ScaleAbsolute(120, 120);
                    pdfImage.Alignment = Element.ALIGN_LEFT;
                    doc.Add(pdfImage);
                }

                doc.Close();

                string filename = $"Bill_{DateTime.Now:yyyyMMdd_HHmmss}.pdf";
                Response.Clear();
                Response.ContentType = "application/pdf";
                Response.AddHeader("content-disposition", $"attachment;filename={filename}");
                Response.BinaryWrite(ms.ToArray());
                Response.Flush();
                Response.End();
            }

            InsertBill();
        }




        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            string searchKeyword = SearchTb.Text.Trim();

            if (!string.IsNullOrEmpty(searchKeyword))
            {
                DataTable allProducts = Con.GetData("Select PId, PName, PPrice, PQty from ProductTb1");

                var filtered = allProducts.AsEnumerable()
                    .Where(row => row.Field<string>("PName").Contains(searchKeyword));

                if (filtered.Any())
                {
                    ProductList.DataSource = filtered.CopyToDataTable();
                    ProductList.DataBind();
                    SetChineseHeaders(); 
                }
                else
                {
                    ProductList.DataSource = null;
                    ProductList.DataBind();
                }
            }
            else
            {
                ShowProducts();
            }
        }
    }
}
