﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineSupermarketTuto.Views.Admin
{
    public partial class Products : System.Web.UI.Page
    {
        Models.Functions Con;

        private int Key
        {
            get { return ViewState["Key"] != null ? (int)ViewState["Key"] : 0; }
            set { ViewState["Key"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            Con = new Models.Functions();
            if (!IsPostBack)
            {
                ShowProducts();
                GetCategories();
                GetManufactors();
            }
        }

        private void ClearFields()
        {
            PNameTb.Value = "";
            PManufactTb.SelectedIndex = -1;
            PCatTb.SelectedIndex = -1;
            QtyTb.Value = "";
            PriceTb.Value = "";
            Key = 0;
        }

        private void ShowProducts()
        {
            string Query = @"
                SELECT 
                    P.PId, 
                    P.PName, 
                    M.ManufactName, 
                    C.CatName, 
                    P.PQty, 
                    P.PPrice,
                    P.PManufact,
                    P.PCategory
                FROM ProductTb1 P
                INNER JOIN ManufactorTb1 M ON P.PManufact = M.ManufactId
                INNER JOIN CategoryTb1 C ON P.PCategory = C.CatId";

            ProductList.DataSource = Con.GetData(Query);
            ProductList.DataKeyNames = new string[] { "PId", "PManufact", "PCategory" }; 
            ProductList.DataBind();

            ProductList.HeaderRow.Cells[1].Text = "序号";
            ProductList.HeaderRow.Cells[2].Text = "商品名称";
            ProductList.HeaderRow.Cells[3].Text = "生产商";
            ProductList.HeaderRow.Cells[4].Text = "商品类型";
            ProductList.HeaderRow.Cells[5].Text = "库存";
            ProductList.HeaderRow.Cells[6].Text = "价格";
        }

        private void GetCategories()
        {
            string Query = "select * from CategoryTb1";
            var dt = Con.GetData(Query);
            PCatTb.DataTextField = "CatName";
            PCatTb.DataValueField = "CatId";
            PCatTb.DataSource = dt;
            PCatTb.DataBind();
        }

        private void GetManufactors()
        {
            string Query = "select * from ManufactorTb1";
            var dt = Con.GetData(Query);
            PManufactTb.DataTextField = "ManufactName";
            PManufactTb.DataValueField = "ManufactId";
            PManufactTb.DataSource = dt;
            PManufactTb.DataBind();
        }

        protected void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (PNameTb.Value == "" || PManufactTb.SelectedIndex == -1 || PCatTb.SelectedIndex == -1 || PriceTb.Value == "" || QtyTb.Value == "")
                {
                    ErrMsg.Text = "信息缺失！";
                }
                else
                {
                    string PName = PNameTb.Value;
                    string PManufact = PManufactTb.SelectedValue.ToString();
                    string PCat = PCatTb.SelectedValue.ToString();
                    int Quantity = Convert.ToInt32(QtyTb.Value);
                    int Price = Convert.ToInt32(PriceTb.Value);

                    string Query = "insert into ProductTb1(PName, PManufact, PCategory, PQty, PPrice) values('{0}',{1},{2},{3},{4})";
                    Query = string.Format(Query, PName, PManufact, PCat, Quantity, Price);
                    Con.SetData(Query);
                    ShowProducts();
                    ErrMsg.Text = "商品信息已添加！";
                    ClearFields();
                }
            }
            catch (Exception Ex)
            {
                ErrMsg.Text = Ex.Message;
            }
        }

        protected void ProductList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = ProductList.SelectedIndex;
            PNameTb.Value = ProductList.SelectedRow.Cells[2].Text;
            QtyTb.Value = ProductList.SelectedRow.Cells[5].Text;
            PriceTb.Value = ProductList.SelectedRow.Cells[6].Text;

            int PManufact = Convert.ToInt32(ProductList.DataKeys[selectedIndex]["PManufact"]);
            int PCategory = Convert.ToInt32(ProductList.DataKeys[selectedIndex]["PCategory"]);

            PManufactTb.SelectedValue = PManufact.ToString();
            PCatTb.SelectedValue = PCategory.ToString();

            Key = Convert.ToInt32(ProductList.DataKeys[selectedIndex]["PId"]);
        }

        protected void EditBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (PNameTb.Value == "" || PManufactTb.SelectedIndex == -1 || PCatTb.SelectedIndex == -1 || PriceTb.Value == "" || QtyTb.Value == "")
                {
                    ErrMsg.Text = "信息缺失！";
                }
                else
                {
                    string PName = PNameTb.Value;
                    string PManufact = PManufactTb.SelectedValue.ToString();
                    string PCat = PCatTb.SelectedValue.ToString();
                    int Quantity = Convert.ToInt32(QtyTb.Value);
                    int Price = Convert.ToInt32(PriceTb.Value);

                    string Query = "Update ProductTb1 set PName='{0}', PManufact={1}, PCategory={2}, PQty={3}, PPrice={4} where PId={5}";
                    Query = string.Format(Query, PName, PManufact, PCat, Quantity, Price, Key);
                    Con.SetData(Query);
                    ShowProducts();
                    ErrMsg.Text = "商品信息已更新！";
                    ClearFields();
                }
            }
            catch (Exception Ex)
            {
                ErrMsg.Text = Ex.Message;
            }
        }

        protected void DeleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (Key == 0)
                {
                    ErrMsg.Text = "请选择要删除的商品！";
                }
                else
                {
                    string Query = "Delete from ProductTb1 where PId={0}";
                    Query = string.Format(Query, Key);
                    Con.SetData(Query);
                    ShowProducts();
                    ErrMsg.Text = "商品信息已删除！";
                    ClearFields();
                }
            }
            catch (Exception Ex)
            {
                ErrMsg.Text = Ex.Message;
            }
        }

       
    }
}
