﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text.RegularExpressions;

namespace OnlineSupermarketTuto.Views
{
    public partial class Login : System.Web.UI.Page
    {
        Models.Functions Con;
        protected void Page_Load(object sender, EventArgs e)
        {
            Con = new Models.Functions();
        }
        public static string UName = "";
        public static int User;
        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$"; 
            string passwordPattern = @"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$"; 

            if (string.IsNullOrEmpty(MailTb.Value) || string.IsNullOrEmpty(PasswordTb.Value))
            {
                ErrMsg.Text = "请输入用户名和密码！";
            }
            else if (!Regex.IsMatch(MailTb.Value, emailPattern))
            {
                ErrMsg.Text = "请输入有效的邮箱地址！";
            }
            else if (!Regex.IsMatch(PasswordTb.Value, passwordPattern))
            {
                ErrMsg.Text = "密码必须至少6位，包含字母和数字！";
            }
            else if (MailTb.Value == "Admin@admin.com" && PasswordTb.Value == "password111")
            {
                Response.Redirect("Admin/Products.aspx");
            }
            else
            {
                var allCustomers = Con.GetData("Select * from CustomerTb1").AsEnumerable();
                var matchedCustomer = allCustomers.FirstOrDefault(row =>
                    row.Field<string>("CustEmail") == MailTb.Value &&
                    row.Field<string>("CustPass") == PasswordTb.Value);

                if (matchedCustomer == null)
                {
                    ErrMsg.Text = "用户名或密码错误！";
                }
                else
                {
                    UName = MailTb.Value;
                    User = matchedCustomer.Field<int>("CustId"); 
                    Response.Redirect("Customer/Billing.aspx");
                }
            }
        }
    }
}